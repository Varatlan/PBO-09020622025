/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas1;

/**
 *
 * @author RIGISEFA
 */
public class Hewan extends MakhlukHidup{
    public Hewan(String nama){
        this.setNama(nama);
    }
}
