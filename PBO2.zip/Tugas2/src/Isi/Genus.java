/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Isi;

/**
 *
 * @author RIGISEFA
 */
public class Genus extends Famili{
    public Genus(){
        super();
    }
    public Genus(String nama){
        super(nama);
    }
    public Genus(String nama, String famili){
        super(nama, famili);
    }
}
