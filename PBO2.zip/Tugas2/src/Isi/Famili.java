/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Isi;

/**
 *
 * @author RIGISEFA
 */
public class Famili extends Darat{
    public Famili(){
        super();
    }
    public Famili(String nama){
        super(nama);
    }
    public Famili(String nama, String famili){
        super(nama, famili);
    }
}
